class Session(object):
    pass
