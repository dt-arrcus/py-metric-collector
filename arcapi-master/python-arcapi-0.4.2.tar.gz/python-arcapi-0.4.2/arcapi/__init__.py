class ArcAPIError(Exception):
    "Base class for all ArcAPI Errors"
    pass
